package com.bronzemantcg.ownership;

import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Locale;
import java.util.Set;
import javax.inject.Inject;
import javax.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

/** One fail-open ownership decision boundary shared by future enforcement and visuals. */
@Slf4j
@Singleton
public final class CardOwnershipService
{
	private static final BetaCardUnlockSource.View NO_BETA_UNLOCKS =
		new BetaCardUnlockSource.View(0L, Collections.emptySet(), Collections.emptySet());
	private final CardResolver resolver;
	private final Set<String> reportedFailOpenDecisions = ConcurrentHashMap.newKeySet();

	@Inject
	public CardOwnershipService(CardResolver resolver)
	{
		this.resolver = resolver;
	}

	public Decision decide(CardEntityKind kind, int entityId, String entityName,
		TcgOwnershipSnapshot personalOwnership, Set<String> sharedCardNames,
		Set<String> exemptCardNames)
	{
		return decide(kind, entityId, entityName, personalOwnership, NO_BETA_UNLOCKS,
			sharedCardNames, exemptCardNames);
	}

	public Decision decide(CardEntityKind kind, int entityId, String entityName,
		TcgOwnershipSnapshot personalOwnership, BetaCardUnlockSource.View betaUnlocks,
		Set<String> sharedCardNames, Set<String> exemptCardNames)
	{
		CardResolver.Result resolved = resolver.resolve(kind, entityId, entityName);
		return decideResolved(resolved, personalOwnership, betaUnlocks, sharedCardNames,
			exemptCardNames, kind, entityId, entityName);
	}

	/**
	 * Decides one name-authored parent-card requirement across the separate item and NPC
	 * namespaces. Exactly one reviewed identity is required; missing or conflicting catalogue
	 * data fails open just like direct entity resolution.
	 */
	public Decision decideCard(String cardName, TcgOwnershipSnapshot personalOwnership,
		Set<String> sharedCardNames, Set<String> exemptCardNames)
	{
		return decideCard(cardName, personalOwnership, NO_BETA_UNLOCKS,
			sharedCardNames, exemptCardNames);
	}

	public Decision decideCard(String cardName, TcgOwnershipSnapshot personalOwnership,
		BetaCardUnlockSource.View betaUnlocks, Set<String> sharedCardNames,
		Set<String> exemptCardNames)
	{
		CardResolver.Result item = resolver.resolveCardName(CardEntityKind.ITEM, cardName);
		CardResolver.Result npc = resolver.resolveCardName(CardEntityKind.NPC, cardName);
		if (item.getStatus() == CardResolver.Status.AMBIGUOUS
			|| npc.getStatus() == CardResolver.Status.AMBIGUOUS
			|| (item.isTracked() && npc.isTracked()))
		{
			logRequirementFailOpenOnce(cardName, Status.AMBIGUOUS);
			return new Decision(Status.AMBIGUOUS, null);
		}
		CardResolver.Result resolved = item.isTracked() ? item : npc;
		if (!resolved.isTracked())
		{
			logRequirementFailOpenOnce(cardName, Status.UNTRACKED);
			return new Decision(Status.UNTRACKED, null);
		}
		return decideIdentity(resolved.getIdentity(), personalOwnership, betaUnlocks,
			sharedCardNames, exemptCardNames);
	}

	/** Decides one parent-card requirement inside an explicit item or NPC namespace. */
	public Decision decideCard(CardEntityKind kind, String cardName,
		TcgOwnershipSnapshot personalOwnership, Set<String> sharedCardNames,
		Set<String> exemptCardNames)
	{
		return decideCard(kind, cardName, personalOwnership, NO_BETA_UNLOCKS,
			sharedCardNames, exemptCardNames);
	}

	public Decision decideCard(CardEntityKind kind, String cardName,
		TcgOwnershipSnapshot personalOwnership, BetaCardUnlockSource.View betaUnlocks,
		Set<String> sharedCardNames, Set<String> exemptCardNames)
	{
		CardResolver.Result resolved = resolver.resolveCardName(kind, cardName);
		if (!resolved.isTracked())
		{
			Status status = map(resolved.getStatus());
			logRequirementFailOpenOnce(kind, cardName, status);
			return new Decision(status, null);
		}
		return decideIdentity(resolved.getIdentity(), personalOwnership, betaUnlocks,
			sharedCardNames, exemptCardNames);
	}

	/**
	 * Additive ownership for collection and readiness displays. Unlike enforcement, unresolved
	 * catalogue data is not treated as collected; only an exact owned/shared name may satisfy an
	 * unresolved row.
	 */
	public boolean isCollectedCard(String cardName, TcgOwnershipSnapshot personalOwnership,
		Set<String> sharedCardNames)
	{
		return isCollectedCard(cardName, personalOwnership, NO_BETA_UNLOCKS, sharedCardNames);
	}

	public boolean isCollectedCard(String cardName, TcgOwnershipSnapshot personalOwnership,
		BetaCardUnlockSource.View betaUnlocks, Set<String> sharedCardNames)
	{
		String normalizedCardName = normalizeCardName(cardName);
		if (normalizedCardName.isEmpty())
		{
			return false;
		}
		if (personalOwnership != null
			&& personalOwnership.getOwnedCardNamesLowerCase().contains(normalizedCardName))
		{
			return true;
		}
		if (containsCardName(sharedCardNames, normalizedCardName))
		{
			return true;
		}

		CardResolver.Result item = resolver.resolveCardName(CardEntityKind.ITEM, cardName);
		CardResolver.Result npc = resolver.resolveCardName(CardEntityKind.NPC, cardName);
		if (item.getStatus() == CardResolver.Status.AMBIGUOUS
			|| npc.getStatus() == CardResolver.Status.AMBIGUOUS
			|| (item.isTracked() && npc.isTracked()))
		{
			return false;
		}
		CardResolver.Result resolved = item.isTracked() ? item : npc;
		if (!resolved.isTracked())
		{
			return false;
		}
		CardIdentity identity = resolved.getIdentity();
		return identity.isCollectedBy(personalOwnership)
			|| isBetaOwned(identity, betaUnlocks)
			|| acceptsUnambiguousSharedName(identity, sharedCardNames);
	}

	/**
	 * Collection/readiness lookup for a row whose item or NPC namespace is known. IDs remain
	 * authoritative when that namespace is present, apart from the same reviewed legacy-name
	 * compatibility rule used by enforcement.
	 */
	public boolean isCollectedCard(CardEntityKind kind, String cardName,
		TcgOwnershipSnapshot personalOwnership, Set<String> sharedCardNames)
	{
		return isCollectedCard(kind, cardName, personalOwnership, NO_BETA_UNLOCKS,
			sharedCardNames);
	}

	public boolean isCollectedCard(CardEntityKind kind, String cardName,
		TcgOwnershipSnapshot personalOwnership, BetaCardUnlockSource.View betaUnlocks,
		Set<String> sharedCardNames)
	{
		String normalizedCardName = normalizeCardName(cardName);
		if (normalizedCardName.isEmpty())
		{
			return false;
		}
		CardResolver.Result resolved = resolver.resolveCardName(kind, cardName);
		if (!resolved.isTracked())
		{
			return false;
		}
		CardIdentity identity = resolved.getIdentity();
		return identity.isOwnedBy(personalOwnership)
			|| acceptsUnambiguousPersonalLegacyName(identity, personalOwnership)
			|| isBetaOwned(identity, betaUnlocks)
			|| acceptsUnambiguousSharedName(identity, sharedCardNames);
	}

	private void logRequirementFailOpenOnce(String cardName, Status status)
	{
		String diagnosticKey = "CARD|" + cardName + "|" + status;
		if (reportedFailOpenDecisions.add(diagnosticKey))
		{
			log.debug("Failing open for parent-card requirement '{}': {}", cardName, status);
		}
	}

	private void logRequirementFailOpenOnce(CardEntityKind kind, String cardName, Status status)
	{
		String diagnosticKey = "CARD|" + kind + "|" + cardName + "|" + status;
		if (reportedFailOpenDecisions.add(diagnosticKey))
		{
			log.debug("Failing open for {} parent-card requirement '{}': {}",
				kind, cardName, status);
		}
	}

	private Decision decideResolved(CardResolver.Result resolved,
		TcgOwnershipSnapshot personalOwnership, BetaCardUnlockSource.View betaUnlocks,
		Set<String> sharedCardNames, Set<String> exemptCardNames, CardEntityKind kind,
		int entityId, String entityName)
	{
		if (!resolved.isTracked())
		{
			if (resolved.getStatus() == CardResolver.Status.AMBIGUOUS
				|| resolved.getStatus() == CardResolver.Status.CATALOG_MISMATCH)
			{
				String diagnosticKey = kind + "|" + entityId + "|" + resolved.getStatus();
				if (reportedFailOpenDecisions.add(diagnosticKey))
				{
					log.debug("Failing open for {} id={} name='{}': {}",
						kind, entityId, entityName, resolved.getStatus());
				}
			}
			return new Decision(map(resolved.getStatus()), null);
		}
		return decideIdentity(resolved.getIdentity(), personalOwnership, betaUnlocks,
			sharedCardNames, exemptCardNames);
	}

	private Decision decideIdentity(CardIdentity identity,
		TcgOwnershipSnapshot personalOwnership, BetaCardUnlockSource.View betaUnlocks,
		Set<String> sharedCardNames, Set<String> exemptCardNames)
	{
		if (identity.acceptsAnyCardName(exemptCardNames))
		{
			return new Decision(Status.EXEMPT, identity);
		}
		if (identity.isOwnedBy(personalOwnership)
			|| acceptsUnambiguousPersonalLegacyName(identity, personalOwnership)
			|| isBetaOwned(identity, betaUnlocks))
		{
			return new Decision(Status.OWNED, identity);
		}
		if (acceptsUnambiguousSharedName(identity, sharedCardNames))
		{
			return new Decision(Status.SHARED, identity);
		}
		return new Decision(Status.LOCKED, identity);
	}

	private boolean isBetaOwned(CardIdentity identity, BetaCardUnlockSource.View betaUnlocks)
	{
		if (identity == null || betaUnlocks == null)
		{
			return false;
		}
		Set<String> betaParents = betaUnlocks.getParentNamesLowerCase(identity.getKind());
		if (isMatchingBetaParent(identity, betaParents, identity.getCardName()))
		{
			return true;
		}
		for (String legacyName : identity.getLegacyCardNames())
		{
			if (isMatchingBetaParent(identity, betaParents, legacyName))
			{
				return true;
			}
		}
		return false;
	}

	private boolean isMatchingBetaParent(CardIdentity identity, Set<String> betaParents,
		String acceptedParentName)
	{
		if (!containsCardName(betaParents, normalizeCardName(acceptedParentName)))
		{
			return false;
		}
		CardResolver.Result parent = resolver.resolveCardName(
			identity.getKind(), acceptedParentName);
		return parent.isTracked() && sameIdentity(identity, parent.getIdentity());
	}

	/**
	 * The current OSRS TCG payload includes historical Beta-owned card names, but it can only
	 * publish entity IDs for names which still resolve in its v1 catalogue. Bridge that narrow
	 * gap without weakening normal v1 ID authority: only a reviewed legacy card-name alias may
	 * satisfy the already-resolved parent, and only when it is unambiguous across both kinds.
	 */
	private boolean acceptsUnambiguousPersonalLegacyName(CardIdentity identity,
		TcgOwnershipSnapshot personalOwnership)
	{
		if (identity == null || personalOwnership == null
			|| !personalOwnership.hasEntityIds(identity.getKind()))
		{
			return false;
		}

		Set<String> ownedNames = personalOwnership.getOwnedCardNamesLowerCase();
		CardEntityKind otherKind = identity.getKind() == CardEntityKind.ITEM
			? CardEntityKind.NPC : CardEntityKind.ITEM;
		for (String legacyCardName : identity.getLegacyCardNames())
		{
			String normalized = normalizeCardName(legacyCardName);
			if (!containsCardName(ownedNames, normalized))
			{
				continue;
			}

			CardResolver.Result sameKind = resolver.resolveCardName(
				identity.getKind(), legacyCardName);
			if (!sameKind.isTracked()
				|| !sameIdentity(identity, sameKind.getIdentity())
				|| resolver.resolveCardName(otherKind, legacyCardName).getStatus()
					!= CardResolver.Status.UNTRACKED)
			{
				continue;
			}
			return true;
		}
		return false;
	}

	/** Names-only shared ownership cannot safely choose between equal item and NPC card names. */
	private boolean acceptsUnambiguousSharedName(CardIdentity identity, Set<String> sharedCardNames)
	{
		if (!identity.acceptsAnyCardName(sharedCardNames))
		{
			return false;
		}
		CardEntityKind otherKind = identity.getKind() == CardEntityKind.ITEM
			? CardEntityKind.NPC : CardEntityKind.ITEM;
		if (containsCardName(sharedCardNames, normalizeCardName(identity.getCardName()))
			&& resolver.resolveCardName(otherKind, identity.getCardName()).getStatus()
				== CardResolver.Status.UNTRACKED)
		{
			return true;
		}
		for (String legacyCardName : identity.getLegacyCardNames())
		{
			if (containsCardName(sharedCardNames, normalizeCardName(legacyCardName))
				&& resolver.resolveCardName(otherKind, legacyCardName).getStatus()
					== CardResolver.Status.UNTRACKED)
			{
				return true;
			}
		}
		return false;
	}

	private static boolean containsCardName(Set<String> names, String lowerCaseCardName)
	{
		if (names == null || names.isEmpty())
		{
			return false;
		}
		// SharedUnlockStore and ExemptionList already provide lower-case sets, so the normal
		// render/menu path remains one hash lookup with no allocation.
		if (names.contains(lowerCaseCardName))
		{
			return true;
		}
		for (String name : names)
		{
			if (name != null && lowerCaseCardName.equals(name.trim().toLowerCase(Locale.ROOT)))
			{
				return true;
			}
		}
		return false;
	}

	private static boolean sameIdentity(CardIdentity first, CardIdentity second)
	{
		return first != null && second != null
			&& first.getKind() == second.getKind()
			&& normalizeCardName(first.getCardName())
				.equals(normalizeCardName(second.getCardName()));
	}

	private static String normalizeCardName(String cardName)
	{
		return cardName == null ? "" : cardName.trim().toLowerCase(Locale.ROOT);
	}

	private static Status map(CardResolver.Status status)
	{
		switch (status)
		{
			case AMBIGUOUS:
				return Status.AMBIGUOUS;
			case CATALOG_MISMATCH:
				return Status.CATALOG_MISMATCH;
			default:
				return Status.UNTRACKED;
		}
	}

	public enum Status
	{
		OWNED(true),
		SHARED(true),
		EXEMPT(true),
		LOCKED(false),
		UNTRACKED(true),
		AMBIGUOUS(true),
		CATALOG_MISMATCH(true);

		private final boolean allowed;

		Status(boolean allowed)
		{
			this.allowed = allowed;
		}

		public boolean isAllowed()
		{
			return allowed;
		}
	}

	public static final class Decision
	{
		private final Status status;
		private final CardIdentity identity;

		private Decision(Status status, CardIdentity identity)
		{
			this.status = status;
			this.identity = identity;
		}

		public Status getStatus()
		{
			return status;
		}

		public boolean isAllowed()
		{
			return status.isAllowed();
		}

		public CardIdentity getIdentity()
		{
			return identity;
		}
	}
}
