package com.bronzemantcg.catalog;


import com.google.gson.Gson;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.function.Predicate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.inject.Inject;
import javax.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

/**
 * Rules for gating skill resource nodes (trees, rocks, fishing spots, pickpocket targets,
 * raw-food-on-fire, ...) behind ownership of the cards of the items they yield or consume.
 * Loaded from resources/nodes/resource_nodes.json, which is hand-curated (assisted by audits of
 * osrs-tcg's Card.json for exact card names) and expected to grow over time.
 *
 * Lookup is by (kind, in-game name, menu option) — all lower-cased. For "item-on-object"
 * rules the roles shift: name = the used item, options = the target object names, because
 * that's what a "Use Raw shrimps -> Fire" click gives us.
 *
 * Requirements come in two data shapes, unified internally into card GROUPS:
 *  - requiredCards + requireAll (legacy): requireAll=true -> each card its own group
 *    (all needed); requireAll=false -> one group (any one card suffices).
 *  - requiredCardGroups (+ optional parallel groupRoles): every group must be satisfied,
 *    a group is satisfied by owning ANY one of its cards. Roles let config modes drop
 *    groups (e.g. runecrafting's "rune" group in Talisman-only mode).
 */
@Slf4j
@Singleton
public class ResourceNodeCatalog
{
	public static final String KIND_OBJECT = "object";
	public static final String KIND_NPC = "npc";
	/** RuneLite FishingSpot enum name + the clicked fishing option. */
	public static final String KIND_FISHING_SPOT = "fishing-spot";
	public static final String KIND_ITEM_ON_OBJECT = "item-on-object";
	public static final String KIND_INVENTORY = "inventory";
	/** Make-interface product clicks; nodes use options ["*"] since only the product name is known. */
	public static final String KIND_INTERFACE = "interface";
	public static final String ANY_OPTION = "*";

	private Map<String, Rule> rules = Collections.emptyMap();
	private List<String> masterFarmerSeedCards = Collections.emptyList();
	// Lowercased names of NPCs carrying "slayer"-category rules (the masters). The NPC
	// visibility sweep exempts them: their interactions answer only to the Slayer section.
	private Set<String> slayerNpcNamesLower = Collections.emptySet();

	@Inject
	public ResourceNodeCatalog(Gson gson)
	{
		load(gson);
	}

	/** Exact card names of every seed on Master Farmer's drop table (for Insanity mode). */
	public List<String> getMasterFarmerSeedCards()
	{
		return masterFarmerSeedCards;
	}

	/** True when this NPC has any slayer-category rule (i.e. it's a slayer master). */
	public boolean isSlayerNpc(String name)
	{
		return name != null && slayerNpcNamesLower.contains(name.trim().toLowerCase(Locale.ROOT));
	}

	/** @return the rule for this interaction, or null if the node is unrestricted. */
	public Rule find(String kind, String name, String option)
	{
		return find(kind, name, option, -1);
	}

	/**
	 * ID-aware lookup for objects whose display name is not specific enough to identify
	 * their loot table (notably Thieving chests, which are commonly all named "Chest").
	 * Exact ID rules take priority; ordinary name-based rules remain the fallback.
	 */
	public Rule find(String kind, String name, String option, int targetId)
	{
		if (name == null || option == null)
		{
			return null;
		}
		String cleanKind = kind.trim().toLowerCase(Locale.ROOT);
		String cleanOption = option.trim().toLowerCase(Locale.ROOT);
		if (targetId >= 0)
		{
			Rule idRule = rules.get(idKey(cleanKind, targetId, cleanOption));
			if (idRule != null)
			{
				return idRule;
			}
		}
		String nameKey = CardNames.stripDoseSuffix(name.trim().toLowerCase(Locale.ROOT));
		return rules.get(key(cleanKind, nameKey, cleanOption));
	}

	public int size()
	{
		return rules.size();
	}

	/**
	 * Unmodifiable view of all rules keyed "kind|name|option" (all lowercased), for the
	 * side panel's progress meters. The same Rule instance appears once per option.
	 */
	public Map<String, Rule> getRuleEntries()
	{
		return rules;
	}

	private static String key(String kind, String nameLower, String optionLower)
	{
		return kind + '|' + nameLower + '|' + optionLower;
	}

	private static String idKey(String kind, int id, String optionLower)
	{
		return kind + "|#" + id + '|' + optionLower;
	}

	private void load(Gson gson)
	{
		try (InputStream stream = getClass().getResourceAsStream(
			"/nodes/resource_nodes.json"))
		{
			if (stream == null)
			{
				log.warn("resource_nodes.json missing from classpath; resource nodes will be unrestricted.");
				return;
			}
			Snapshot snapshot = gson.fromJson(
				new InputStreamReader(stream, StandardCharsets.UTF_8), Snapshot.class);
			if (snapshot == null || snapshot.nodes == null)
			{
				return;
			}
			Map<String, Rule> map = new HashMap<>();
			Set<String> slayerNames = new HashSet<>();
			for (NodeDto node : snapshot.nodes)
			{
				if (node == null || node.kind == null || node.name == null || node.options == null)
				{
					continue;
				}
				List<CardGroup> groups = buildGroups(node);
				if (groups.isEmpty())
				{
					continue;
				}
				Rule rule = new Rule(node.category, groups);
				String kindLower = node.kind.trim().toLowerCase(Locale.ROOT);
				String nameLower = node.name.trim().toLowerCase(Locale.ROOT);
				if ("slayer".equals(node.category)
					&& KIND_NPC.equals(kindLower))
				{
					slayerNames.add(nameLower);
				}
				for (String option : node.options)
				{
					if (option != null && !option.trim().isEmpty())
					{
						String optionLower = option.trim().toLowerCase(Locale.ROOT);
						if (node.objectIds != null && !node.objectIds.isEmpty())
						{
							for (Integer objectId : node.objectIds)
							{
								if (objectId != null && objectId >= 0)
								{
									map.put(idKey(kindLower, objectId, optionLower), rule);
								}
							}
						}
						else
						{
							map.put(key(kindLower, nameLower, optionLower), rule);
						}
					}
				}
			}
			rules = Collections.unmodifiableMap(map);
			slayerNpcNamesLower = Collections.unmodifiableSet(slayerNames);
			if (snapshot.masterFarmerSeedCards != null)
			{
				masterFarmerSeedCards = Collections.unmodifiableList(snapshot.masterFarmerSeedCards);
			}
			log.info("Loaded {} resource node rules ({} Master Farmer seeds) from snapshot",
				rules.size(), masterFarmerSeedCards.size());
		}
		catch (IOException ex)
		{
			log.warn("Failed to load resource_nodes.json", ex);
		}
	}

	private static List<CardGroup> buildGroups(NodeDto node)
	{
		List<CardGroup> groups = new ArrayList<>();
		if (node.requiredCardGroups != null)
		{
			for (int i = 0; i < node.requiredCardGroups.size(); i++)
			{
				List<String> cards = node.requiredCardGroups.get(i);
				String role = node.groupRoles != null && i < node.groupRoles.size()
					? node.groupRoles.get(i) : null;
				String label = node.groupLabels != null && i < node.groupLabels.size()
					? node.groupLabels.get(i) : null;
				CardGroup group = CardGroup.of(cards, role, label);
				if (group != null)
				{
					groups.add(group);
				}
			}
		}
		else if (node.requiredCards != null)
		{
			if (node.requireAll)
			{
				for (String card : node.requiredCards)
				{
					CardGroup group = CardGroup.of(Collections.singletonList(card), null, null);
					if (group != null)
					{
						groups.add(group);
					}
				}
			}
			else
			{
				CardGroup group = CardGroup.of(node.requiredCards, null, null);
				if (group != null)
				{
					groups.add(group);
				}
			}
		}
		return groups;
	}

	public static class Rule
	{
		public final String category;
		public final List<CardGroup> groups;

		Rule(String category, List<CardGroup> groups)
		{
			this.category = category == null ? "" : category.toLowerCase(Locale.ROOT);
			this.groups = Collections.unmodifiableList(groups);
		}

		/**
		 * @param owned         lower-cased owned card names
		 * @param excludedRoles group roles a config mode has switched off (never null)
		 * @param forceAllInGroups treat any-of groups as all-required (stall thieving "All items")
		 * @return display strings for each unsatisfied requirement, empty when allowed.
		 *         Any-of groups render as "A / B" so the player sees the alternatives.
		 */
		public List<String> missingRequirements(Set<String> owned, Set<String> excludedRoles,
			boolean forceAllInGroups)
		{
			return missingRequirements(owned::contains, excludedRoles, forceAllInGroups);
		}

		public List<String> missingRequirements(Predicate<String> ownsCard,
			Set<String> excludedRoles, boolean forceAllInGroups)
		{
			List<String> missing = new ArrayList<>();
			for (CardGroup group : groups)
			{
				if (group.role != null && excludedRoles.contains(group.role))
				{
					continue;
				}
				if (forceAllInGroups)
				{
					for (int i = 0; i < group.displayCards.size(); i++)
					{
						if (!ownsCard.test(group.lowerCards.get(i)))
						{
							missing.add(group.displayCards.get(i));
						}
					}
				}
				else if (!group.isSatisfied(ownsCard))
				{
					missing.add(String.join(" / ", group.displayCards));
				}
			}
			return missing;
		}

		/** Missing requirements from one named role only; unlabelled groups are ignored. */
		public List<String> missingRequirementsForRole(Set<String> owned, String includedRole)
		{
			return missingRequirementsForRole(owned::contains, includedRole);
		}

		public List<String> missingRequirementsForRole(Predicate<String> ownsCard,
			String includedRole)
		{
			if (includedRole == null)
			{
				return Collections.emptyList();
			}
			String cleanRole = includedRole.trim().toLowerCase(Locale.ROOT);
			List<String> missing = new ArrayList<>();
			for (CardGroup group : groups)
			{
				if (cleanRole.equals(group.role) && !group.isSatisfied(ownsCard))
				{
					missing.add(String.join(" / ", group.displayCards));
				}
			}
			return missing;
		}
	}

	public static class CardGroup
	{
		/** Original casing, for chat messages; lowerCards is index-aligned. */
		public final List<String> displayCards;
		public final List<String> lowerCards;
		public final String role;
		public final String label;

		private CardGroup(List<String> displayCards, List<String> lowerCards, String role,
			String label)
		{
			this.displayCards = Collections.unmodifiableList(displayCards);
			this.lowerCards = Collections.unmodifiableList(lowerCards);
			this.role = role;
			this.label = label;
		}

		static CardGroup of(List<String> cards, String role, String label)
		{
			if (cards == null)
			{
				return null;
			}
			List<String> display = new ArrayList<>();
			List<String> lower = new ArrayList<>();
			for (String card : cards)
			{
				if (card != null && !card.trim().isEmpty())
				{
					display.add(card.trim());
					lower.add(card.trim().toLowerCase(Locale.ROOT));
				}
			}
			if (display.isEmpty())
			{
				return null;
			}
			String cleanRole = role == null || role.trim().isEmpty()
				? null : role.trim().toLowerCase(Locale.ROOT);
			String cleanLabel = label == null || label.trim().isEmpty()
				? display.get(0) : label.trim();
			return new CardGroup(display, lower, cleanRole, cleanLabel);
		}

		public boolean isSatisfied(Predicate<String> ownsCard)
		{
			for (String card : lowerCards)
			{
				if (ownsCard.test(card))
				{
					return true;
				}
			}
			return false;
		}
	}

	private static class Snapshot
	{
		List<NodeDto> nodes;
		List<String> masterFarmerSeedCards;
	}

	private static class NodeDto
	{
		String category;
		String kind;
		String name;
		List<String> options;
		List<Integer> objectIds;
		List<String> requiredCards;
		List<List<String>> requiredCardGroups;
		List<String> groupRoles;
		List<String> groupLabels;
		boolean requireAll;
	}
}
